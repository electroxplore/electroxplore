import { Zap, Mail, Phone, MapPin, Send, Globe, Play, GitBranch } from "lucide-react"
import { Separator } from "@/components/ui/separator"

const quickLinks = [
  { label: "Home", href: "#home" },
  { label: "Research Groups", href: "#research" },
  { label: "Training Courses", href: "#training" },
  { label: "Our Team", href: "#team" },
  { label: "About Us", href: "#about" },
  { label: "Gallery", href: "#gallery" },
  { label: "FAQ", href: "#faq" },
  { label: "Privacy Policy", href: "/privacy" },
  { label: "Terms & Conditions", href: "/terms" },
]

const socials = [
  { icon: Send, label: "Twitter / X", href: "#" },
  { icon: Globe, label: "LinkedIn", href: "#" },
  { icon: GitBranch, label: "GitHub", href: "#" },
  { icon: Play, label: "YouTube", href: "#" },
]

export default function Footer() {
  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">

          {/* Column 1: Brand + Contact */}
          <div className="space-y-5">
            <a href="#home" className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center flex-shrink-0">
                <Zap className="w-5 h-5 text-primary-foreground" fill="currentColor" />
              </div>
              <span className="font-heading font-bold text-foreground text-xl tracking-tight">
                Electro<span className="text-primary">Xplore</span>
              </span>
            </a>

            <p className="text-muted-foreground text-sm leading-relaxed max-w-xs">
              Engineering research and training for the next generation of innovators. Membership-based, community-driven.
            </p>

            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                <span className="text-muted-foreground text-sm">Dhaka, Bangladesh</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-primary flex-shrink-0" />
                <a href="tel:+8801700000000" className="text-muted-foreground text-sm hover:text-foreground transition-colors">
                  +880 1700-000000
                </a>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-primary flex-shrink-0" />
                <a href="mailto:hello@electroxplore.org" className="text-muted-foreground text-sm hover:text-foreground transition-colors">
                  hello@electroxplore.org
                </a>
              </div>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="space-y-5">
            <h4 className="text-foreground font-heading font-bold text-xs uppercase tracking-widest">Quick Links</h4>
            <ul className="grid grid-cols-2 gap-y-2.5 gap-x-4">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-muted-foreground hover:text-primary text-sm transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Social + Fields */}
          <div className="space-y-5">
            <h4 className="text-foreground font-heading font-bold text-xs uppercase tracking-widest">Follow Us</h4>
            <div className="flex flex-wrap gap-3">
              {socials.map(({ icon: Icon, label, href }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="w-10 h-10 bg-surface rounded-xl flex items-center justify-center text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors border border-border"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>

            <div className="pt-2 space-y-2">
              <h4 className="text-foreground font-heading font-bold text-xs uppercase tracking-widest">Research Fields</h4>
              <div className="flex flex-wrap gap-2">
                {["EEE", "CSE", "ETE", "CCE", "ME", "AI/ML"].map((f) => (
                  <span key={f} className="text-xs bg-primary/10 text-primary border border-primary/20 rounded-full px-3 py-1">
                    {f}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        <Separator className="bg-border my-8" />

        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-muted-foreground text-xs">
            &copy; {new Date().getFullYear()} ElectroXplore. All rights reserved.
          </p>
          <div className="flex gap-4">
            <a href="/privacy" className="text-muted-foreground hover:text-foreground text-xs transition-colors">Privacy Policy</a>
            <a href="/terms" className="text-muted-foreground hover:text-foreground text-xs transition-colors">Terms & Conditions</a>
          </div>
        </div>
      </div>
    </footer>
  )
}
